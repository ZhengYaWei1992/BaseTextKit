//
//  ZWLabel.swift
//  007-TextKit
//
//  Created by 郑亚伟 on 16/11/23.
//  Copyright © 2016年 郑亚伟. All rights reserved.
//

import UIKit


/*
 1.使用textKit接替label的底层实现  ---绘制textStorage的文本内容
 2.使用正则表达式过滤URL
 3.交互
 
 -UILabel默认不能垂直顶部对齐，但是使用text可以实现。drawText这个系统方法很重要
 */
class ZWLabel: UILabel {
    //MARK:-TextKit核心对象
    /// 负责文本存储
    lazy var textStorage = NSTextStorage()
    /// 负责文本字形布局
    lazy var layoutManager = NSLayoutManager()
    /// 设定文本绘制的范围
    lazy var textContainer = NSTextContainer()

    //MARK:-重写属性 --进一步体会TextKit接管底层的实现
    //一旦内容变化，需要textStorage响应
    //-提示：在iOS7.0之前实现这种效果要用coreText，使用起来异常繁琐
    //-YYModel的作者开发了一个框架YYText，自己建立了一套渲染系统
    override var text: String?{
        didSet{
            /*******************************************/
            //如果不重写这个方法，外部不能更改label文本内容
            //重新准备文本内容
            prepareTextContent()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.orange
        prepareTextSystem()
    }
    
    required init?(coder aDecoder: NSCoder) {
       // fatalError("init(coder:) has not been implemented")
        super.init(coder: aDecoder)
        backgroundColor = UIColor.orange
        prepareTextSystem()
    }
    
    
    /// ****系统方法*****
    ///绘制文本
    override func drawText(in rect: CGRect){
        //消除父类的绘制，这里我们自己绘制
       // super.drawText(in: rect)
        let range = NSRange(location: 0, length: textStorage.length)
        /***********************************************/
        //要注意着两者的关系，应该先绘制背景，再绘制字形。如果反过来，文字就看不见
        //绘制背景
        layoutManager.drawBackground(forGlyphRange: range, at:  CGPoint())
        //绘制Glyph字形    CGPoint()表示从原点开始绘制
        layoutManager.drawGlyphs(forGlyphRange: range, at: CGPoint())
        
    }
    
    /// ****系统方法*****
    override func layoutSubviews() {
        super.layoutSubviews()
        //指定文本的绘制区域
        textContainer.size = bounds.size
    }
    
    /// ****系统方法*****
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        //1.获取用户点击的位置
        //first?相当于OC的anyObject
        guard let location = touches.first?.location(in: self)else{
            return
        }
        print("点我了\(location)")
        //2.记录当前点中字符的索引
       let idx = layoutManager.glyphIndex(for: location, in: textContainer)
        print("点我了\(idx)")
        //3.判断idx是否在url的range范围内，如果在就高亮
        for r in urlRanges ?? []{
            //NSRanege跳入头文件可以看见次方法 NSLocationInRange
            if NSLocationInRange(idx, r){
                print("需要高亮")
                //修改文本的字体属性
                textStorage.addAttributes([NSForegroundColorAttributeName:UIColor.blue], range: r)
                //如果需要重新绘制，需要调用setNeedsDisplay方法
                setNeedsDisplay()
            }else{
                print("没点到")
            }
        }
    }
}


// MARK: - 设置textKit核心对象
private extension ZWLabel{
    ///准备文本系统
    func prepareTextSystem(){
        //0.开启用户交互
        isUserInteractionEnabled = true
        //1.准备文本内容
         prepareTextContent()
        //2.设置对象的关系  ---一般都是固定的写法
        textStorage.addLayoutManager(layoutManager)
        layoutManager.addTextContainer(textContainer)
    }
    
    
    /// 准备文本内容，接管label内容
    func prepareTextContent(){
        if let attributedText = attributedText{
            textStorage.setAttributedString(attributedText)
        }else if let text = text{
            textStorage.setAttributedString(NSAttributedString(string: text))
        }else{
            textStorage.setAttributedString(NSAttributedString(string: ""))
        }
       // print(urlRanges)
        //遍历范围数组，设置URL文字的属性
        for r in urlRanges ?? []{
            textStorage.addAttributes([NSForegroundColorAttributeName:UIColor.red,NSBackgroundColorAttributeName:UIColor.init(white: 0.9, alpha: 1.0)], range: r)
        }
    }
}


// MARK: - 正则表达式获取url范围
extension ZWLabel{
    
    ///返回textStorage中的URL range数组
    var urlRanges: [NSRange]?{
        //1.正则表达式   网上搜索((http|ftp|https)://)(([a-zA-Z0-9\._-]+\.[a-zA-Z]{2,6})|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\&%_\./-~-]*)?
        let pattern = "[a-zA-Z]*://[a-zA-Z0-9/\\.]*"
         //let pattern = "((http|ftp|https)://)(([a-zA-Z0-9\\._-]+\\.[a-zA-Z]{2,6})|([0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}))(:[0-9]{1,4})*(/[a-zA-Z0-9\\&%_\\./-~-]*)?"
        
        guard let regx = try? NSRegularExpression(pattern: pattern, options: [])else{
            return nil
        }
        //2.多重匹配，因为一个字符串中可能包含多个url
       let matches = regx.matches(in: textStorage.string, options: [], range:NSRange(location: 0, length: textStorage.length))
        //3.遍历数组，生成range数组
        var ranges = [NSRange]()
        for m in matches{
            //print("sssssssssssssssssss")
            ranges.append(m.rangeAt(0))
        }
        
        return ranges
    }
}








