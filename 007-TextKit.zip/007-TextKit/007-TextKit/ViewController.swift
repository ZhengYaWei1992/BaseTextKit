//
//  ViewController.swift
//  007-TextKit
//
//  Created by 郑亚伟 on 16/11/23.
//  Copyright © 2016年 郑亚伟. All rights reserved.
//
/*
 textKit的三个核心对象：
 NSTextStorage   存储文本内容
 NSLayoutManager   字形
 NSTextContainer    一般开发很少用，定义一个矩形区域，也可以定义一个排除路径
 */

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: ZWLabel!
    override func viewDidLoad() {
        super.viewDidLoad()
       label.text = "请点击http://www.baidu.com"
       
    }

}

